#!/bin/bash

num=$1

if [ -z "$num" ]
  then
    echo "No number supplied defaulting to 25..."
    num="25"
fi

echo ""

node main.js $num

echo -e "\nNote: This was written in TypeScript and compiled to JavaScript. I inlcuded the ts file but this script will run the compiled js file to avoid having everyone compile it."
